package com.epam.harshu_OOPS_maven.chocolates;

public class Cadbury extends Chocolate {

    public Cadbury(String name,int price,int weight){
        super(name,price,weight);
    }
}
