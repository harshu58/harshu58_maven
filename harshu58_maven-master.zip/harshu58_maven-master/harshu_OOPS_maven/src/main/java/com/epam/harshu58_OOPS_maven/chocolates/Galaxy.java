package com.epam.harshu_OOPS_maven.chocolates;

public class Galaxy extends Chocolate {

    public Galaxy(String name,int price,int weight){
        super(name,price,weight);
    }
}
